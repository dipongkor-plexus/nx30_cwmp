#!/bin/sh
(
    sleep 8

    # মূল সার্ভিস ও ওয়েব ইনজেকশন কল
    [ -f /mnt/config/cfgmd5/cwmp/autostart_cwmp.sh ] && /bin/sh /mnt/config/cfgmd5/cwmp/autostart_cwmp.sh
    [ -f /mnt/config/cfgmd5/cwmp/inject_cwmp.sh ] && /bin/sh /mnt/config/cfgmd5/cwmp/inject_cwmp.sh

    # uHTTPd ওয়াচডগ স্ক্রিপ্ট ব্যাকগ্রাউন্ডে চালু করা
    killall -9 uhttpd_watchdog.sh 2>/dev/null || true
    if [ -f /mnt/config/cfgmd5/cwmp/uhttpd_watchdog.sh ]; then
        /bin/sh /mnt/config/cfgmd5/cwmp/uhttpd_watchdog.sh >/dev/null 2>&1 &
    fi

    # easycwmpd মনিটরিং
    sleep 20
    while true; do
        sleep 20
        if ! ps | grep -v grep | grep -q "easycwmpd"; then
            echo "[WATCHDOG] easycwmpd down! Rebooting..." > /dev/console
            sync
            reboot -f
        fi
    done
) >/dev/null 2>&1 &
exit 0
