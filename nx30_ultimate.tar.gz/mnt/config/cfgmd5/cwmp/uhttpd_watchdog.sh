#!/bin/sh

# সিস্টেম পুরোপুরি বুট হওয়া পর্যন্ত অপেক্ষা
sleep 25

REBOOT_FILE="/mnt/config/cfgmd5/cwmp/uhttpd_reboot_count"
[ ! -f "$REBOOT_FILE" ] && echo "0" > "$REBOOT_FILE"

check_and_recover() {
    COUNT=$(cat "$REBOOT_FILE" 2>/dev/null || echo "0")
    echo "[!] uHTTPd / Port 8888 issue detected. Attempting restart..." > /dev/console
    
    # uhttpd রিস্টার্ট টেস্ট
    OUTPUT=$(/etc/init.d/uhttpd restart 2>&1 || true)
    sleep 4

    # যদি "Not found" আসে অথবা পোর্ট ৮৮৮৮ এখনও চালু না হয়
    if echo "$OUTPUT" | grep -qi "Not found" || ! netstat -tulpn 2>/dev/null | grep -q ":8888 "; then
        if [ "$COUNT" -lt 2 ]; then
            NEXT_COUNT=$((COUNT + 1))
            echo "$NEXT_COUNT" > "$REBOOT_FILE"
            sync
            echo "[CRITICAL] Recovery failed (Count: $NEXT_COUNT/2). Rebooting router..." > /dev/console
            sleep 2
            reboot -f
        else
            echo "[ALERT] Max reboot limit (2) reached. Resetting counter to prevent bootloop." > /dev/console
            echo "0" > "$REBOOT_FILE"
            sync
        fi
    else
        # সফলভাবে চালু হলে কাউন্টার ০ করে দেওয়া
        [ "$COUNT" -ne 0 ] && echo "0" > "$REBOOT_FILE" && sync
    fi
}

# সার্বক্ষণিক মনিটরিং লুপ
while true; do
    sleep 20

    # প্রসেস বা পোর্ট ৮৮৮৮ চেক
    if ! ps | grep -v grep | grep -q "uhttpd" || ! netstat -tulpn 2>/dev/null | grep -q ":8888 "; then
        check_and_recover
    fi
done
